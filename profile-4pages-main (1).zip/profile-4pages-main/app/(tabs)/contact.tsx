import { StyleSheet, Text, View, Linking, TouchableOpacity } from 'react-native';

export default function ContactScreen() {
  return (
    <View style={styles.container}>
      <Text style={styles.title}>Contact Information</Text>

      <Text style={styles.label}>Name</Text>
      <Text style={styles.text}>Franco Guerrero Mera</Text>

      <Text style={styles.label}>Email</Text>
      <TouchableOpacity onPress={() => Linking.openURL('mailto:francogm09@gmail.com')}>
        <Text style={styles.link}>francogm09@gmail.com</Text>
      </TouchableOpacity>

      <Text style={styles.label}>Phone</Text>
      <TouchableOpacity onPress={() => Linking.openURL('tel:+13102139656')}>
        <Text style={styles.link}>+1 (310) 213-9656</Text>
      </TouchableOpacity>

      <Text style={styles.label}>GitHub</Text>
      <TouchableOpacity onPress={() => Linking.openURL('https://github.com/Franco-Guerrero-Mera/profile')}>
        <Text style={styles.link}>github.com/Franco-Guerrero-Mera</Text>
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 24,
    backgroundColor: 'white',
  },
  title: {
    fontSize: 26,
    fontWeight: 'bold',
    marginBottom: 24,
    textAlign: 'center',
  },
  label: {
    fontSize: 16,
    fontWeight: '600',
    marginTop: 16,
  },
  text: {
    fontSize: 16,
    color: '#333',
  },
  link: {
    fontSize: 16,
    color: '#007AFF',
  },
});
