import React from 'react';
import { StyleSheet, Image, View, Text } from 'react-native';
import { ThemedView } from '@/components/ThemedView';

export default function AboutScreen() {
  return (
    <View style={styles.gradientBackground}>
      <ThemedView style={styles.container}>
        {/* Avatar with gradient border */}
        <View style={styles.avatarWrapper}>
          <Image
            source={require('@/assets/images/Me.jpeg')}
            style={styles.avatar}
          />
        </View>

        {/* Name */}
        <Text style={styles.name}>FRANCO GM</Text>

        {/* Bio Card */}
        <View style={styles.bioCard}>
          <Text style={styles.bioText}>
            Hi! I’m Franco, a software engineer specializing in mobile and web
            applications. I love building seamless user experiences and crafting
            clean, maintainable code. When I’m not coding, you’ll find me hiking
            or reading sci-fi novels.
          </Text>
        </View>
      </ThemedView>
    </View>
  );
}





const styles = StyleSheet.create({
  gradientBackground: {
    flex: 1,
    backgroundColor: 'linear-gradient(180deg, #e0f7fa 0%, #fce4ec 100%)',
  },
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 32,
  },
  avatarWrapper: {
    borderRadius: 80,
    padding: 4,
    backgroundColor: 'linear-gradient(45deg, #6dd5fa, #f7797d)',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.25,
    shadowRadius: 6,
    elevation: 8, // Android shadow
    marginBottom: 24,
  },
  avatar: {
    width: 140,
    height: 140,
    borderRadius: 70,
  },
  name: {
    fontSize: 20,
    fontWeight: '700',
    letterSpacing: 2,
    marginBottom: 16,
    textAlign: 'center',
    color: '#222',
  },
  bioCard: {
    backgroundColor: '#fff',
    padding: 20,
    borderRadius: 16,
    maxWidth: 320,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.15,
    shadowRadius: 8,
    elevation: 4,
  },
  bioText: {
    fontSize: 16,
    lineHeight: 24,
    textAlign: 'center',
    color: '#444',
  },
});
